/*
 * music.h
 *
 *  Created on: Dec 4, 2023
 *      Author: mvosburg
 */

#ifndef MUSIC_H_
#define MUSIC_H_

void load_song();

#endif /* MUSIC_H_ */
